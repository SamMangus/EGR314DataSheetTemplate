#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/uart1.h"

#pragma config FEXTOSC = OFF            
#pragma config RSTOSC = HFINTOSC_64MHZ 
// CONFIG2
#pragma config CLKOUTEN = OFF
#pragma config PR1WAY   = ON
#pragma config CSWEN    = ON
#pragma config FCMEN    = ON
// CONFIG3
#pragma config MCLRE    = EXTMCLR
#pragma config PWRTS    = PWRT_OFF
#pragma config MVECEN   = ON
#pragma config IVT1WAY  = ON
#pragma config LPBOREN  = OFF
#pragma config BOREN    = SBORDIS
// CONFIG4
#pragma config ZCD      = OFF
#pragma config PPS1WAY  = ON
#pragma config STVREN   = ON
#pragma config LVP      = ON           
// CONFIG5
#pragma config CP       = OFF

// ---------------------------------------------------------------------------
// Class Message Protocol Constants
// ---------------------------------------------------------------------------
#define MSG_PREFIX      'A'
#define MSG_SECOND      'Z'
#define MSG_SUFFIX_1    'Y'
#define MSG_SUFFIX_2    'B'

#define MY_ID           5
#define DEST_ID         1       // Sam B HMI (subsystem 1)
#define BROADCAST_ID    0

#define MAX_PAYLOAD     58
#define BUFFER_SIZE     64

#define MSG_PRINT_SENSOR_VALUE  '3'     // Type  3  we SEND  (ASCII '3')
#define MSG_SUBSYS_STATUS_CODE  'C'     // Type 12  we RECEIVE (ASCII hex 'C' = 0x43)
#define MSG_SUBSYS_STATUS_REPLY 'D'     // Type 13  we SEND   (ASCII hex 'D' = 0x44)

// Valid team member IDs 
static const uint8_t TEAM_IDS[] = {1, 2, 3, 4, 6};

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
#define TC74_ADDR     0x4C
#define TC74_TEMP_REG 0x00

#define BB_SCL_LOW()  do { LATBbits.LATB1 = 0; } while(0)
#define BB_SCL_HIGH() do { LATBbits.LATB1 = 1; } while(0)
#define BB_SDA_LOW()  do { LATBbits.LATB0 = 0; } while(0)
#define BB_SDA_HIGH() do { LATBbits.LATB0 = 1; } while(0)
#define BB_SDA_READ() (PORTBbits.RB0)
#define BB_DELAY()    __delay_us(10)   

static void BB_I2C_Init(void) {
    I2C2CON0bits.EN = 0;   
    RB1PPS = 0x00;         
    RB0PPS = 0x00;        
    ANSELB &= ~0x03;     
    TRISBbits.TRISB1 = 0;  
    TRISBbits.TRISB0 = 0;  
    BB_SCL_HIGH();
    BB_SDA_HIGH();
    BB_DELAY();
}

static void BB_Start(void) {
    BB_SDA_HIGH(); BB_DELAY();
    BB_SCL_HIGH(); BB_DELAY();
    BB_SDA_LOW();  BB_DELAY();
    BB_SCL_LOW();  BB_DELAY();
}

static void BB_Stop(void) {
    BB_SDA_LOW();  BB_DELAY();
    BB_SCL_HIGH(); BB_DELAY();
    BB_SDA_HIGH(); BB_DELAY();
}

static uint8_t BB_WriteByte(uint8_t b) {
    int8_t i;
    for (i = 7; i >= 0; i--) {
        if (b & (1 << i)) BB_SDA_HIGH(); else BB_SDA_LOW();
        BB_DELAY();
        BB_SCL_HIGH(); BB_DELAY();
        BB_SCL_LOW();  BB_DELAY();
    }
    BB_SDA_HIGH(); BB_DELAY();
    BB_SCL_HIGH(); BB_DELAY();
    uint8_t ack = !BB_SDA_READ();
    BB_SCL_LOW();  BB_DELAY();
    return ack;
}

static uint8_t BB_ReadByte(uint8_t send_ack) {
    uint8_t b = 0;
    int8_t i;
    BB_SDA_HIGH();
    for (i = 7; i >= 0; i--) {
        BB_DELAY();
        BB_SCL_HIGH(); BB_DELAY();
        if (BB_SDA_READ()) b |= (1 << i);
        BB_SCL_LOW();
    }
    if (send_ack) BB_SDA_LOW(); else BB_SDA_HIGH();
    BB_DELAY();
    BB_SCL_HIGH(); BB_DELAY();
    BB_SCL_LOW();  BB_DELAY();
    BB_SDA_HIGH();
    return b;
}

int8_t TC74_ReadTemperature(void) {
    BB_Start();
    if (!BB_WriteByte(TC74_ADDR << 1)) { BB_Stop(); return 0; }
    if (!BB_WriteByte(TC74_TEMP_REG))  { BB_Stop(); return 0; }
    BB_Start();
    if (!BB_WriteByte((TC74_ADDR << 1) | 1)) { BB_Stop(); return 0; }
    uint8_t data = BB_ReadByte(0);
    BB_Stop();
    return (int8_t)data;
}

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
void led_flash(uint8_t count) {
    for (uint8_t i = 0; i < count; i++) {
        LATEbits.LATE0 = 1;
        __delay_ms(150);
        LATEbits.LATE0 = 0;
        __delay_ms(150);
    }
}

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
void uart1_send_byte(uint8_t b) {
    while (!U1FIFObits.TXBE);
    U1TXB = b;
}

void uart1_send_buf(const uint8_t *buf, uint8_t len) {
    for (uint8_t i = 0; i < len; i++)
        uart1_send_byte(buf[i]);
}

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
void send_packet(const uint8_t *payload, uint8_t payload_len, uint8_t dest) {
    if (payload_len > MAX_PAYLOAD) payload_len = MAX_PAYLOAD;
    uint8_t frame[BUFFER_SIZE];
    uint8_t i;
    frame[0] = MSG_PREFIX;
    frame[1] = MSG_SECOND;
    frame[2] = MY_ID + '0';
    frame[3] = dest + '0';
    for (i = 0; i < payload_len; i++) {
        uint8_t b = payload[i];
        if (b == MSG_PREFIX || b == MSG_SUFFIX_1) b = 0x00;
        frame[4 + i] = b;
    }
    frame[4 + payload_len]     = MSG_SUFFIX_1;
    frame[4 + payload_len + 1] = MSG_SUFFIX_2;
    uart1_send_buf(frame, 4 + payload_len + 2);
}

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
void send_temperature(int8_t temp) {
    uint8_t t = (temp < 0) ? 0 : (uint8_t)temp;
    if (t > 99) t = 99;
    uint8_t payload[5];
    payload[0] = '3';                     // message type 3 ASCII
    payload[1] = '3';                     // sensor #3 ASCII (matches MessageCompliance.X)
    payload[2] = '0' + (t / 100);         // hundreds digit
    payload[3] = '0' + ((t / 10) % 10);   // tens digit
    payload[4] = '0' + (t % 10);          // units digit
    send_packet(payload, 5, DEST_ID);
}

// ---------------------------------------------------------------------------

// ---------------------------------------------------------------------------
typedef enum {
    RX_WAIT_PREFIX1,
    RX_WAIT_PREFIX2,
    RX_WAIT_SENDER,
    RX_WAIT_RECEIVER,
    RX_WAIT_PAYLOAD,
    RX_WAIT_SUFFIX1
} RxState_t;

typedef struct {
    uint8_t sender;
    uint8_t receiver;
    uint8_t payload[MAX_PAYLOAD];
    uint8_t payload_len;
    bool    ready;
} Packet_t;

static RxState_t rx_state      = RX_WAIT_PREFIX1;
static uint8_t   rx_sender     = 0;
static uint8_t   rx_receiver   = 0;
static uint8_t   rx_buf[MAX_PAYLOAD];
static uint8_t   rx_idx        = 0;
static uint8_t   raw_frame[BUFFER_SIZE];
static uint8_t   raw_frame_idx = 0;

static uint8_t   fwd_buf[BUFFER_SIZE];
static uint8_t   fwd_len       = 0;
static bool      fwd_pending   = false;
static bool      fwd_flag      = false;
static bool      error_flag    = false;

static Packet_t  rx_packet;

bool is_team_member(uint8_t id) {
    for (uint8_t i = 0; i < sizeof(TEAM_IDS); i++)
        if (TEAM_IDS[i] == id) return true;
    return false;
}

void poll_rx(void) {
    while (UART1_IsRxReady()) {

        if (U1ERRIRbits.RXFOIF || U1ERRIRbits.FERIF) {
            U1ERRIRbits.RXFOIF = 0;
            rx_state      = RX_WAIT_PREFIX1;
            raw_frame_idx = 0;
            rx_idx        = 0;
            error_flag    = true;
            return;
        }

        uint8_t b = UART1_Read();

        switch (rx_state) {

            case RX_WAIT_PREFIX1:
                if (b == MSG_PREFIX) {
                    raw_frame_idx = 0;
                    raw_frame[raw_frame_idx++] = b;
                    rx_state = RX_WAIT_PREFIX2;
                }
                break;

            case RX_WAIT_PREFIX2:
                if (b == MSG_SECOND) {
                    raw_frame[raw_frame_idx++] = b;
                    rx_state = RX_WAIT_SENDER;
                } else {
                    rx_state      = RX_WAIT_PREFIX1;
                    raw_frame_idx = 0;
                    error_flag    = true;
                }
                break;

            case RX_WAIT_SENDER:
                rx_sender = (b >= '0' && b <= '9') ? (b - '0') : b;
                raw_frame[raw_frame_idx++] = b;
                rx_state = RX_WAIT_RECEIVER;
                break;

            case RX_WAIT_RECEIVER:
                rx_receiver = (b >= '0' && b <= '9') ? (b - '0') : b;
                raw_frame[raw_frame_idx++] = b;
                rx_idx   = 0;
                rx_state = RX_WAIT_PAYLOAD;
                break;

            case RX_WAIT_PAYLOAD:
                if (b == MSG_SUFFIX_1) {
                    raw_frame[raw_frame_idx++] = b;
                    rx_state = RX_WAIT_SUFFIX1;
                } else {
                    if (rx_idx < MAX_PAYLOAD) {
                        rx_buf[rx_idx++]           = b;
                        raw_frame[raw_frame_idx++] = b;
                    } else {
                        rx_state      = RX_WAIT_PREFIX1;
                        raw_frame_idx = 0;
                        rx_idx        = 0;
                        error_flag    = true;
                    }
                }
                break;

            case RX_WAIT_SUFFIX1:
                if (b == MSG_SUFFIX_2) {
                    raw_frame[raw_frame_idx++] = b;

                    if (rx_sender == MY_ID) {
                        rx_state = RX_WAIT_PREFIX1; raw_frame_idx = 0; rx_idx = 0;
                        error_flag = true;
                        break;
                    }

                    if (!is_team_member(rx_sender) && rx_sender != BROADCAST_ID) {
                        rx_state = RX_WAIT_PREFIX1; raw_frame_idx = 0; rx_idx = 0;
                        error_flag = true;
                        break;
                    }

                    if (rx_receiver == MY_ID || rx_receiver == BROADCAST_ID) {
                        if (!rx_packet.ready) {
                            rx_packet.sender      = rx_sender;
                            rx_packet.receiver    = rx_receiver;
                            rx_packet.payload_len = rx_idx;
                            memcpy(rx_packet.payload, rx_buf, rx_idx);
                            rx_packet.ready = true;
                        }
                    }

                    if (rx_receiver != MY_ID && !fwd_pending) {
                        memcpy(fwd_buf, raw_frame, raw_frame_idx);
                        fwd_len     = raw_frame_idx;
                        fwd_pending = true;
                        fwd_flag    = true;
                    }

                    rx_state = RX_WAIT_PREFIX1; raw_frame_idx = 0; rx_idx = 0;

                } else {
                    if (rx_idx < MAX_PAYLOAD) rx_buf[rx_idx++] = MSG_SUFFIX_1;
                    if (rx_idx < MAX_PAYLOAD) rx_buf[rx_idx++] = b;
                    raw_frame[raw_frame_idx++] = b;
                    rx_state = RX_WAIT_PAYLOAD;
                }
                break;

            default:
                rx_state = RX_WAIT_PREFIX1;
                break;
        }
    }
}

// ---------------------------------------------------------------------------
// Handle a received packet addressed to us
// ---------------------------------------------------------------------------
void process_packet(const Packet_t *pkt) {
    if (pkt->payload_len == 0) return;
    uint8_t msg_type = pkt->payload[0];

    switch (msg_type) {
        case MSG_SUBSYS_STATUS_CODE: {     // Type 12 received as ASCII 'C' (0x43)
            uint8_t ack[3];
            ack[0] = MSG_SUBSYS_STATUS_REPLY;  // 'D' = Type 13
            ack[1] = MY_ID + '0';              // our subsystem ID as ASCII ('5')
            ack[2] = '0';                      // status code '0' = OK
            send_packet(ack, 3, pkt->sender);
            break;
        }
        default:
            break;
    }
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------
void main(void) {
    SYSTEM_Initialize();
    INTCON0bits.GIEH = 1;
    INTCON0bits.GIEL = 1;

    // RE0 LED
    TRISEbits.TRISE0   = 0;
    ANSELEbits.ANSELE0 = 0;
    LATEbits.LATE0     = 0;

    BB_I2C_Init();
    __delay_ms(250);   // TC74 power-on settle

    memset(&rx_packet, 0, sizeof(rx_packet));
    rx_packet.ready = false;

    uint8_t tick = 0;   // counts 500 ms slices; send at 10 (= 5 seconds)

    while (1) {

        for (uint16_t ms = 0; ms < 500; ms++) {
            __delay_ms(1);
            poll_rx();

            if (fwd_pending) {
                uart1_send_buf(fwd_buf, fwd_len);
                fwd_pending = false;
            }

            if (rx_packet.ready) {
                led_flash(1);
                process_packet(&rx_packet);
                rx_packet.ready = false;
            }

            if (fwd_flag) {
                fwd_flag = false;
                led_flash(2);
            }

            if (error_flag) {
                error_flag = false;
                led_flash(3);
            }
        }

        if (++tick >= 10) {
            tick = 0;
            int8_t temp = TC74_ReadTemperature();
            send_temperature(temp);
        }
    }
}
