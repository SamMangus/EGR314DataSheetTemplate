/**
 * System Driver File
 */

#include "../system.h"
#include "../clock.h"
#include "../pins.h"
#include "../../uart/uart1.h"

void SYSTEM_Initialize(void)
{
    CLOCK_Initialize();
    PIN_MANAGER_Initialize();
    UART1_Initialize();
}
