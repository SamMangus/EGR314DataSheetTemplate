#ifndef SYSTEM_H
#define SYSTEM_H

#include <xc.h>
#include <stdint.h>
#include <stdbool.h>
#include "clock.h"
#include "pins.h"
#include "interrupt.h"

void SYSTEM_Initialize(void);

#endif /* SYSTEM_H */
