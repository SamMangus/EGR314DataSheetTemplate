#ifndef CONFIG_BITS_H
#define CONFIG_BITS_H

/* Config bits are defined via #pragma config in main.c */

#endif /* CONFIG_BITS_H */
